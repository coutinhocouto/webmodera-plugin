<?php
/*
   Plugin Name: Global Videos
   Plugin URI: https://www.globalvideos.com.br
   description: >- Plugins para os sites de eventos
   Version: 1.0,0
   Author: Global Videos
   Author URI: https://www.globalvideos.com.br
   License: GPL2
   */

add_action( 'admin_init','global-videos');

function global_cadastra_form($atts)
{ 
    
    $atts = shortcode_atts(
        array(
            'evento' => '',
        ), $atts, 'global_cadastra_form' );

        wp_register_style('global-videos', plugins_url('style.css',__FILE__ ));
        wp_register_script( 'global-videos', plugins_url('custom.js',__FILE__ ));


    ?>

    <form action="#" method="post">

        <input type="hidden" value="5" name="evento" /> 

        <div class="wb-100">
            <label form="area">Área de atuação *</label>
            <select name="area-atuacao" required>
                <option>Selecione</option>
                <option value="Medicina">Medicina</option>
                <option value="Farmácia">Farmácia</option>
                <option value="Enfermagem">Enfermagem</option>
                <option value="Nutrição">Nutrição</option>
                <option value="Psicologia">Psicologia</option>
                <option value="Gestão em Saúde">Gestão em Saúde</option>
                <option value="Educação Física">Educação Física</option>
                <option value="Gerontologia">Gerontologia</option>
                <option value="Fisioterapia">Fisioterapia</option>
                <option value="Odontologia">Odontologia</option>
                <option value="Biomedicina">Biomedicina</option>
            </select>
        </div>

        <div class="wb-33">
            <label form="crm_uf">Estado do CRM *</label>
            <select name="crm_uf" required>
                <option>Selecione</option>
                <option value="AC">AC</option>
                <option value="AL">AL</option>
                <option value="AP">AP</option>
                <option value="AM">AM</option>
                <option value="BA">BA</option>
                <option value="CE">CE</option>
                <option value="DF">DF</option>
                <option value="ES">ES</option>
                <option value="GO">GO</option>
                <option value="MA">MA</option>
                <option value="MT">MT</option>
                <option value="MS">MS</option>
                <option value="MG">MG</option>
                <option value="PA">PA</option>
                <option value="PB">PB</option>
                <option value="PR">PR</option>
                <option value="PE">PE</option>
                <option value="PI">PI</option>
                <option value="RJ">RJ</option>
                <option value="RN">RN</option>
                <option value="RS">RS</option>
                <option value="RO">RO</option>
                <option value="RR">RR</option>
                <option value="SC">SC</option>
                <option value="SP">SP</option>
                <option value="SE">SE</option>
                <option value="TO">TO</option>
            </select>
        </div>

        <div class="wb-33">
            <label form="crm">CRM (somente números) *</label>
            <input type="text" name="crm" required />
        </div>

        <div class="wb-33">
            <button id="valida_crm">Validar CRM</button>
        </div>

        <div class="wb-100">
            <label form="nome">Nome Completo *</label>
            <input type="text" name="nome" required />
        </div>

        <div class="wb-100">
            <label form="nome">E-mail *</label>
            <input type="text" name="email" required />
        </div>

        <div class="wb-100">
            <label form="especialidade">Especialidade *</label>
            <select name="especialidade" required>
                <option value="Acupuntura">Acupuntura</option>
                <option value="Alergia e imunologia">Alergia e imunologia</option>
                <option value="Alergia e imunologia pediátrica">Alergia e imunologia pediátrica</option>
                <option value="Anestesiologia">Anestesiologia</option>
                <option value="Angiologia">Angiologia</option>
                <option value="Cardiologia">Cardiologia</option>
                <option value="Cardiologia pediátrica">Cardiologia pediátrica</option>
                <option value="Cirurgia bariátrica">Cirurgia bariátrica</option>
                <option value="Cirurgia cardiovascular">Cirurgia cardiovascular</option>
                <option value="Cirurgia da mão">Cirurgia da mão</option>
                <option value="Cirurgia de cabeça e pescoço">Cirurgia de cabeça e pescoço</option>
                <option value="Cirurgia do aparelho digestivo">Cirurgia do aparelho digestivo</option>
                <option value="Cirurgia geral">Cirurgia geral</option>
                <option value="Cirurgia oncológica">Cirurgia oncológica</option>
                <option value="Cirurgia pediátrica">Cirurgia pediátrica</option>
                <option value="Cirurgia plástica">Cirurgia plástica</option>
                <option value="Cirurgia torácica">Cirurgia torácica</option>
                <option value="Cirurgia vascular">Cirurgia vascular</option>
                <option value="Clínica médica">Clínica médica</option>
                <option value="Coloproctologia">Coloproctologia</option>
                <option value="Dermatologia">Dermatologia</option>
                <option value="Dor">Dor</option>
                <option value="Endocrinologia e metabologia">Endocrinologia e metabologia</option>
                <option value="Endocrinologia pediátrica">Endocrinologia pediátrica</option>
                <option value="Endoscopia">Endoscopia</option>
                <option value="Gastroenterologia">Gastroenterologia</option>
                <option value="Gastroenterologia pediátrica">Gastroenterologia pediátrica</option>
                <option value="Genética médica">Genética médica</option>
                <option value="Geriatria">Geriatria</option>
                <option value="Ginecologia e obstetrícia">Ginecologia e obstetrícia</option>
                <option value="Hematologia e hemoterapia">Hematologia e hemoterapia</option>
                <option value="Hematologia e hemoterapia pediátrica">Hematologia e hemoterapia pediátrica</option>
                <option value="Hepatologia">Hepatologia</option>
                <option value="Homeopatia">Homeopatia</option>
                <option value="Infectologia">Infectologia</option>
                <option value="Infectologia pediátrica">Infectologia pediátrica</option>
                <option value="Mastologia">Mastologia</option>
                <option value="Medicina de emergência">Medicina de emergência</option>
                <option value="Medicina de família e comunidade">Medicina de família e comunidade</option>
                <option value="Medicina de tráfego">Medicina de tráfego</option>
                <option value="Medicina do trabalho">Medicina do trabalho</option>
                <option value="Medicina esportiva">Medicina esportiva</option>
                <option value="Medicina física e reabilitação">Medicina física e reabilitação</option>
                <option value="Medicina intensiva">Medicina intensiva</option>
                <option value="Medicina intensiva pediátrica">Medicina intensiva pediátrica</option>
                <option value="Medicina legal e perícia médica">Medicina legal e perícia médica</option>
                <option value="Medicina nuclear">Medicina nuclear</option>
                <option value="Medicina preventiva e social">Medicina preventiva e social</option>
                <option value="Nefrologia">Nefrologia</option>
                <option value="Nefrologia pediátrica">Nefrologia pediátrica</option>
                <option value="Neurocirurgia">Neurocirurgia</option>
                <option value="Neurologia">Neurologia</option>
                <option value="Neurologia pediátrica">Neurologia pediátrica</option>
                <option value="Nutrologia">Nutrologia</option>
                <option value="Oftalmologia">Oftalmologia</option>
                <option value="Oncologia clínica">Oncologia clínica</option>
                <option value="Oncologia pediátrica">Oncologia pediátrica</option>
                <option value="Ortopedia e traumatologia">Ortopedia e traumatologia</option>
                <option value="Otorrinolaringologia">Otorrinolaringologia</option>
                <option value="Patologia">Patologia</option>
                <option value="Patologia clínica/medicina laboratorial">Patologia clínica/medicina laboratorial</option>
                <option value="Pediatria">Pediatria</option>
                <option value="Pneumologia">Pneumologia</option>
                <option value="Pneumologia pediátrica">Pneumologia pediátrica</option>
                <option value="Psiquiatria">Psiquiatria</option>
                <option value="Radiologia e diagnóstico por imagem">Radiologia e diagnóstico por imagem</option>
                <option value="Radioterapia">Radioterapia</option>
                <option value="Reumatologia">Reumatologia</option>
                <option value="Reumatologia pediátrica">Reumatologia pediátrica</option>
                <option value="Urologia">Urologia</option>
            </select>

        </div>

        <div class="wb-50">
            <label form="uf">Estado</label>
            <select name="uf" required>
                <option>Selecione</option>
                <option value="AC">AC</option>
                <option value="AL">AL</option>
                <option value="AP">AP</option>
                <option value="AM">AM</option>
                <option value="BA">BA</option>
                <option value="CE">CE</option>
                <option value="DF">DF</option>
                <option value="ES">ES</option>
                <option value="GO">GO</option>
                <option value="MA">MA</option>
                <option value="MT">MT</option>
                <option value="MS">MS</option>
                <option value="MG">MG</option>
                <option value="PA">PA</option>
                <option value="PB">PB</option>
                <option value="PR">PR</option>
                <option value="PE">PE</option>
                <option value="PI">PI</option>
                <option value="RJ">RJ</option>
                <option value="RN">RN</option>
                <option value="RS">RS</option>
                <option value="RO">RO</option>
                <option value="RR">RR</option>
                <option value="SC">SC</option>
                <option value="SP">SP</option>
                <option value="SE">SE</option>
                <option value="TO">TO</option>
            </select>
        </div>

        <div class="wb-50">
            <label form="cidade">Cidade *</label>
            <select name="cidade" required>
                <option>Selecione</option>
            </select>
        </div>

        <div class="wb-100">
            <label form="nome">Telefone (com ddd) *</label>
            <input type="text" name="email" required />
        </div>

        <div class="wb-100">
            <label form="sabendo">Como ficou sabendo? *</label>
            <select name="sabendo" required>
                <option>Selecione</option>
                <option value="E-mail marketing">E-mail marketing</option>
                <option value="Redes sociais">Redes sociais</option>
                <option value="Sociedade Médica">Sociedade Médica</option>
                <option value="Representante">Representante</option>
                <option value="Outros">Outros</option>
            </select>
        </div>

        <div class="wb-100">
            <label form="termo">Aceito receber e-mails sobre programas de educação continuada, via Editora Clannad</label>
            <input type="checkbox" name="termo" value="Ok">
        </div>

        <div class="wb-100">
            <label form="termo2">Estou ciente de que este site é restrito ao público prescritor e assumo completa responsabilidade pela veracidade das informações acima *</label>
            <input type="checkbox" name="termo2" value="Ok" required>
        </div>

        <div class="wb-50">
            <label form="nome">Senha</label>
            <input type="password" name="password" required />
        </div>

        <div class="wb-50">
            <label form="nome">Confirme sua senha</label>
            <input type="password" name="cpassword" required />
        </div>


    </form>

<?php }

add_shortcode('cadastro', 'global_cadastra_form');
