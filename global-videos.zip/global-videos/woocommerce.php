<?php

add_action('woocommerce_order_status_completed', 'my_function');
function my_function($order_id)
{

    // order object (optional but handy)
    $order = new WC_Order($order_id);

    foreach ($order->get_items() as $item) {
        $produto = $item['name'];
    }

    $user_id = get_post_meta($order_id, '_customer_user', true);
    $user_info = get_userdata(get_post_meta($order_id, '_customer_user', true));

    $nome = get_user_meta($user_id, 'first_name');
    $sobrenome = get_user_meta($user_id, 'last_name');
    $email = $user_info->user_email;
    $uf = get_user_meta($user_id, 'billing_state');
    $cidade = get_user_meta($user_id, 'billing_city');
    $profissao = get_user_meta($user_id, 'billing_area_atuacao');
    $pais = get_user_meta($user_id, 'billing_country');
    $cep = get_user_meta($user_id, 'billing_postcode');
    $telefone = get_user_meta($user_id, 'billing_phone');
    $cpf = get_user_meta($user_id, 'billing_cpf');
    $crm = get_user_meta($user_id, 'billing_crm');
    $crm_uf = get_user_meta($user_id, 'billing_crm_uf');
    $especialidade = get_user_meta($user_id, 'billing_espec_medica');
    $sexo = get_user_meta($user_id, 'sexo');
    $evento = get_option('evento_global');
    $pagante = 1;
    $codigo = get_user_meta($user_id, 'codigo');

    $valor = $order->get_total();

    $url = 'https://4k5zxy0dui.execute-api.us-east-1.amazonaws.com/webmodera/webhook';

    $data = array(
        "evento" => $evento,
        "email" => $email,
        "nome" => $nome,
        "sobrenome" => $sobrenome,
        "uf" => $uf,
        "cidade" => $cidade,
        "profissao" => $profissao,
        "pais" => $pais,
        "cep" => $cep,
        "telefone" => $telefone,
        "cpf" => $cpf,
        "crm" => $crm,
        "crm_uf" => $crm_uf,
        "especialidade" => $especialidade,
        "codigo" => $codigo,
        "sexo" => $sexo,
        "produto" => $produto,
        "valor" => $valor,
        "pagante" => $pagante
    );

    $postdata = json_encode($data);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    $result = curl_exec($ch);
    curl_close($ch);
    print_r($result);
}


// Do NOT include the opening php tag.
// Place in your theme's functions.php file

/**
 * You can use the following example to add virtually any custom fields
 * to the checkout page. To more specifically control the location, use
 * our hook guide: https://kb.checkoutwc.com/article/25-actions
 */

/**
 * Add the field to the checkout page
 */
add_action( 'crm_method_terms_checkbox', 'customise_checkout_field' );
function customise_checkout_field() {
	cfw_form_field(
		'crm', array(
		'type'              => 'text',
		'label'             => 'Número do conselho',
		'placeholder'       => '',
		'required'          => true,
		'class'             => array(),
		'autofocus'         => false,
		'input_class'       => array( 'garlic-auto-save' ),
		'priority'          => 10,
		'wrap'              => \Objectiv\Plugins\Checkout\FormAugmenter::instance()->input_wrap( 'textarea', 12, 10 ),
		'label_class'       => 'cfw-input-label',
		'start'             => true,
		'end'               => true,
		'custom_attributes' => array(
			'data-parsley-trigger' => 'change focusout',
		),
	), WC()->checkout->get_value( 'customised_field_name' )
	);
}

/**
 * Update value of field
 */
add_action( 'woocommerce_checkout_update_order_meta', 'customise_checkout_field_update_order_meta' );
function customise_checkout_field_update_order_meta( $order_id ) {
	if ( ! empty( $_POST['crm'] ) ) {
		update_post_meta( $order_id, 'crm', sanitize_text_field( $_POST['crm'] ) );
	}
}

/**
 * Display field value on the order edit page
 */
add_action( 'woocommerce_admin_order_data_after_billing_address', 'crm_meta', 10, 1 );
function crm_checkout_field_display_admin_order_meta($order){
	echo '<p><strong>'.__('CRM').':</strong> <br/>' . get_post_meta( $order->get_id(), 'crm', true ) . '</p>';
}
