jQuery(document).ready(function( $ ){
    console.log('aqui jaz webmodera')
}